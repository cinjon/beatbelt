bb.cmp = top layer copper
bb.sol = bottom layer copper
bb.plc = top silkscreen and outline
bb.pls = bottom silkscreen
bb.stc = top soldermask
bb.sts = bottom soldermask
bb.drd = excellon drill file

Contact Information
Ivan Sergeev
vsergeev@gmail.com
858-699-8387

Cinjon Resnick
cinjon.resnick@gmail.com
617-909-7863

